import { parentPort, workerData } from 'node:worker_threads'
import { pathToFileURL } from 'node:url'

const pending = []
let messageHandler = null
const messageListeners = new Set()
const errorListeners = new Set()

globalThis.self ??= globalThis
globalThis.postMessage ??= (value, transfer) => parentPort?.postMessage(value, transfer)
globalThis.close ??= () => parentPort?.close()
Object.defineProperty(globalThis, 'onmessage', {
  configurable: true,
  get: () => messageHandler,
  set: (handler) => {
    messageHandler = typeof handler === 'function' ? handler : null
    if (!messageHandler) return
    for (const data of pending.splice(0)) messageHandler({ data })
  },
})
globalThis.addEventListener ??= (type, listener) => {
  if (type === 'message') messageListeners.add(listener)
  if (type === 'error') errorListeners.add(listener)
}
globalThis.removeEventListener ??= (type, listener) => {
  if (type === 'message') messageListeners.delete(listener)
  if (type === 'error') errorListeners.delete(listener)
}
parentPort?.on('message', (data) => {
  if (messageHandler) messageHandler({ data })
  else pending.push(data)
  for (const listener of messageListeners) listener({ data })
})
parentPort?.on('messageerror', (error) => {
  const event = { error, message: error?.message ?? String(error) }
  for (const listener of errorListeners) listener(event)
})

const entry = workerData?.entry
if (!entry) throw new Error('worker-bootstrap: missing workerData.entry')
await import(pathToFileURL(entry).href)
