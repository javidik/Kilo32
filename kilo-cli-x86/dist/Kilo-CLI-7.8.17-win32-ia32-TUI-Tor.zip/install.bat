@echo off
setlocal
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo Windows PowerShell was not found. Install Windows PowerShell 5.1 or later.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo Installation failed.
  pause
  exit /b 1
)
echo.
echo Installation complete. Close this window and open a new terminal.
pause
