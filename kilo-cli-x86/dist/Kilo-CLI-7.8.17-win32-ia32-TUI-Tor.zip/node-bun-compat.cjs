'use strict';

// Minimal compatibility surface for the Kilo CLI's documented Node runtime path.
// This intentionally uses Node built-ins; no Bun executable is required.
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const util = require('node:util');
const cp = require('node:child_process');
const { Readable, Writable } = require('node:stream');
let micromatch;
try { micromatch = require('micromatch'); } catch { micromatch = null; }
const { fileURLToPath } = require('node:url');

function asPath(value) {
  if (value instanceof URL) return fileURLToPath(value);
  return String(value);
}

class BunFile {
  constructor(file, start = 0, end = undefined) {
    this.name = asPath(file);
    this.start = start;
    this.end = end;
  }
  async exists() {
    try { await fsp.access(this.name); return true; } catch { return false; }
  }
  async stat() { return fsp.stat(this.name); }
  async text() {
    const data = await fsp.readFile(this.name);
    return data.subarray(this.start, this.end).toString('utf8');
  }
  async json() { return JSON.parse(await this.text()); }
  async bytes() {
    const data = await fsp.readFile(this.name);
    return new Uint8Array(data.subarray(this.start, this.end));
  }
  async arrayBuffer() {
    const b = await this.bytes();
    return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
  }
  async delete() { await fsp.unlink(this.name); }
  async write(data) { return BunCompat.write(this.name, data); }
  stream() {
    const stream = fs.createReadStream(this.name, { start: this.start, end: this.end === undefined ? undefined : Math.max(this.start, this.end - 1) });
    return Readable.toWeb(stream);
  }
  slice(start = 0, end = undefined) {
    const baseStart = this.start + Math.max(0, start);
    const baseEnd = end === undefined ? this.end : this.start + Math.max(0, end);
    return new BunFile(this.name, baseStart, baseEnd);
  }
  get size() {
    try {
      const size = fs.statSync(this.name).size;
      return Math.max(0, Math.min(this.end ?? size, size) - this.start);
    } catch { return 0; }
  }
  get lastModified() {
    try { return fs.statSync(this.name).mtimeMs; } catch { return 0; }
  }
}

async function toBuffer(data) {
  if (data == null) return Buffer.alloc(0);
  if (Buffer.isBuffer(data)) return data;
  if (data instanceof BunFile) return Buffer.from(await data.bytes());
  if (typeof data === 'string') return Buffer.from(data);
  if (data instanceof ArrayBuffer) return Buffer.from(data);
  if (ArrayBuffer.isView(data)) return Buffer.from(data.buffer, data.byteOffset, data.byteLength);
  if (typeof Response !== 'undefined' && data instanceof Response) return Buffer.from(await data.arrayBuffer());
  if (data && typeof data.getReader === 'function') {
    const reader = data.getReader();
    const chunks = [];
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      chunks.push(Buffer.from(value));
    }
    return Buffer.concat(chunks);
  }
  if (data && typeof data.pipe === 'function') {
    const chunks = [];
    for await (const chunk of data) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks);
  }
  return Buffer.from(String(data));
}

const BunCompat = {
  file(file) { return new BunFile(file); },
  async write(file, data) {
    const target = asPath(file);
    await fsp.mkdir(path.dirname(target), { recursive: true }).catch(() => {});
    await fsp.writeFile(target, await toBuffer(data));
  },
  sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); },
  gc() {
    try { if (global.gc) global.gc(); } catch {}
  },
  inspect(value, options) { return util.inspect(value, options); },
  which(command) {
    const envPath = process.env.PATH || '';
    const extensions = process.platform === 'win32'
      ? (process.env.PATHEXT || '.COM;.EXE;.BAT;.CMD').split(';')
      : [''];
    for (const directory of envPath.split(path.delimiter)) {
      for (const extension of extensions) {
        const candidate = path.resolve(directory || '.', command + extension);
        try { if (fs.statSync(candidate).isFile()) return candidate; } catch {}
      }
    }
    return null;
  },
  hash(value) {
    const digest = crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 16);
    return BigInt('0x' + digest);
  },
  CryptoHasher: class {
    constructor(algorithm) { this.hash = crypto.createHash(algorithm); }
    update(data, encoding) { this.hash.update(data, encoding); return this; }
    digest(encoding) { return this.hash.digest(encoding); }
  },
  stringWidth(value) {
    // Width is only used by optional text UI paths in this headless server build.
    return Array.from(String(value).replace(/\x1b\[[0-9;]*m/g, '')).length;
  },
  stdin: {
    stream() { return Readable.toWeb(process.stdin); },
    async text() {
      const chunks = [];
      for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
      return Buffer.concat(chunks).toString('utf8');
    }
  },
  spawn(command, options = {}) {
    const args = Array.isArray(command) ? command.slice(1) : (options.args || []);
    const executable = Array.isArray(command) ? command[0] : command;
    const stdio = [
      options.stdin === 'pipe' ? 'pipe' : (options.stdin || 'ignore'),
      options.stdout === 'pipe' ? 'pipe' : (options.stdout || 'inherit'),
      options.stderr === 'pipe' ? 'pipe' : (options.stderr || 'inherit')
    ];
    const child = cp.spawn(executable, args, {
      cwd: options.cwd,
      env: options.env || process.env,
      stdio,
      windowsHide: options.windowsHide !== false,
      detached: options.detached,
      shell: options.shell === true
    });
    const exited = new Promise((resolve) => {
      child.once('error', () => resolve(1));
      child.once('close', (code) => resolve(typeof code === 'number' ? code : 1));
    });
    const output = child.stdout ? Readable.toWeb(child.stdout) : null;
    const error = child.stderr ? Readable.toWeb(child.stderr) : null;
    const input = child.stdin ? Writable.toWeb(child.stdin) : null;
    return {
      pid: child.pid,
      stdin: input,
      stdout: output,
      stderr: error,
      exited,
      kill(signal) { return child.kill(signal); },
      ref() { child.ref(); },
      unref() { child.unref(); }
    };
  },
  spawnSync(command, options = {}) {
    const args = Array.isArray(command) ? command.slice(1) : (options.args || []);
    const executable = Array.isArray(command) ? command[0] : command;
    const result = cp.spawnSync(executable, args, {
      cwd: options.cwd,
      env: options.env || process.env,
      encoding: options.encoding,
      input: options.stdin,
      windowsHide: options.windowsHide !== false,
      timeout: options.timeout,
      maxBuffer: options.maxBuffer || 64 * 1024 * 1024
    });
    return {
      success: result.status === 0 && !result.error,
      exitCode: result.status == null ? 1 : result.status,
      signal: result.signal,
      stdout: result.stdout == null ? Buffer.alloc(0) : Buffer.from(result.stdout),
      stderr: result.stderr == null ? Buffer.alloc(0) : Buffer.from(result.stderr),
      error: result.error
    };
  },
  Glob: class {
    constructor(pattern) { this.pattern = String(pattern).replace(/\\/g, '/'); this.regex = globRegex(this.pattern); }
    match(value) { return this.regex.test(String(value).replace(/\\/g, '/')); }
    scanSync(options = {}) {
      const cwd = path.resolve(options.cwd || process.cwd());
      const onlyFiles = options.onlyFiles === true;
      const includeDirs = !onlyFiles;
      const results = [];
      const walk = (dir, relative) => {
        let entries;
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
        for (const entry of entries) {
          const abs = path.join(dir, entry.name);
          const rel = relative ? relative + '/' + entry.name : entry.name;
          if (entry.isDirectory()) {
            if (includeDirs && this.match(rel)) results.push(options.absolute ? abs : rel);
            walk(abs, rel);
          } else if (entry.isFile() || entry.isSymbolicLink()) {
            if (this.match(rel)) results.push(options.absolute ? abs : rel);
          }
        }
      };
      walk(cwd, '');
      return results;
    }
    async *scan(options = {}) {
      for (const value of this.scanSync(options)) yield value;
    }
  },
  async $() { throw new Error('Bun.$ shell template is unavailable in this Node-compatible Kilo runtime'); }
};

function globMatch(pattern, value) {
  const normalizedPattern = String(pattern).replace(/\\/g, '/');
  const normalizedValue = String(value).replace(/\\/g, '/');
  if (micromatch) {
    const opts = { dot: true, matchBase: false, nobrace: false, noext: false };
    if (micromatch.isMatch(normalizedValue, normalizedPattern, opts)) return true;
    if (normalizedPattern.startsWith('**/') && micromatch.isMatch(normalizedValue, normalizedPattern.slice(3), opts)) return true;
    return false;
  }
  let out = '^';
  for (let i = 0; i < normalizedPattern.length; i++) {
    const c = normalizedPattern[i];
    if (c === '*' && normalizedPattern[i + 1] === '*') {
      i++;
      if (normalizedPattern[i + 1] === '/') { i++; out += '(?:.*/)?'; }
      else out += '.*';
    } else if (c === '*') out += '[^/]*';
    else if (c === '?') out += '[^/]';
    else if (c === '{') out += '(?:';
    else if (c === ',') out += '|';
    else if (c === '}') out += ')';
    else out += c.replace(/[|\\{}()[\]^$+?.]/g, '\\$&');
  }
  out += '$';
  try { return new RegExp(out).test(normalizedValue); } catch { return false; }
}

BunCompat.Glob = class {
  constructor(pattern) { this.pattern = String(pattern).replace(/\\/g, '/'); }
  match(value) { return globMatch(this.pattern, value); }
  scanSync(options = {}) {
    const cwd = path.resolve(options.cwd || process.cwd());
    const onlyFiles = options.onlyFiles === true;
    const dot = options.dot === true;
    const results = [];
    const walk = (dir, relative) => {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const entry of entries) {
        if (!dot && entry.name.startsWith('.')) continue;
        const abs = path.join(dir, entry.name);
        const rel = relative ? relative + '/' + entry.name : entry.name;
        if (entry.isDirectory()) {
          if (!onlyFiles && this.match(rel)) results.push(options.absolute ? abs : rel);
          walk(abs, rel);
        } else if (entry.isFile() || (options.followSymlinks && entry.isSymbolicLink())) {
          if (this.match(rel)) results.push(options.absolute ? abs : rel);
        }
      }
    };
    walk(cwd, '');
    return results;
  }
  async *scan(options = {}) {
    for (const value of this.scanSync(options)) yield value;
  }
};

BunCompat.$ = function(strings, ...values) {
  const quote = (value) => {
    const text = String(value);
    if (/^[A-Za-z0-9_./:=+@-]+$/.test(text)) return text;
    return '"' + text.replace(/"/g, '""') + '"';
  };
  const command = strings.reduce((out, part, index) => out + part + (index < values.length ? quote(values[index]) : ''), '');
  let cwd = process.cwd(), env = process.env, quiet = false, noThrow = false;
  const execute = async () => {
    const result = cp.spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', command], {
      cwd, env, encoding: null, windowsHide: true, maxBuffer: 64 * 1024 * 1024
    });
    const out = {
      stdout: Buffer.from(result.stdout || []), stderr: Buffer.from(result.stderr || []),
      exitCode: typeof result.status === 'number' ? result.status : 1,
      success: result.status === 0 && !result.error,
      text() { return this.stdout.toString('utf8'); }, json() { return JSON.parse(this.text()); }
    };
    if (result.error) out.error = result.error;
    if (!out.success && !noThrow) {
      const error = new Error(out.stderr.toString('utf8') || out.stdout.toString('utf8') || 'Shell command failed');
      Object.assign(error, out); throw error;
    }
    if (!quiet && out.stderr.length) process.stderr.write(out.stderr);
    return out;
  };
  const promise = Promise.resolve().then(execute);
  promise.cwd = (value) => { cwd = value; return promise; };
  promise.env = (value) => { env = { ...env, ...value }; return promise; };
  promise.quiet = () => { quiet = true; return promise; };
  promise.nothrow = () => { noThrow = true; return promise; };
  promise.text = async () => (await promise).stdout.toString('utf8');
  promise.json = async () => JSON.parse(await promise.text());
  return promise;
};

globalThis.Bun = BunCompat;

// IA-32 Windows compatibility: tunnel Kilo Gateway HTTPS requests through the
// configured HTTP(S)_PROXY using Node's net/tls stack. This avoids the
// experimental undici environment-proxy path that is unreliable under Wine.
const __kiloOriginalFetch = globalThis.fetch.bind(globalThis);
const __kiloHttps = require('node:https');
const __kiloNet = require('node:net');
const __kiloTls = require('node:tls');
const __kiloReadable = require('node:stream').Readable;
const __kiloProxyAgents = new Map();
class __KiloGatewayTunnelAgent extends __kiloHttps.Agent {
  constructor(proxy) { super({ keepAlive: true }); this.proxy = proxy; }
  createConnection(options, callback) {
    const proxy = this.proxy;
    const socket = __kiloNet.connect(Number(proxy.port || 80), proxy.hostname);
    let buffer = Buffer.alloc(0);
    let completed = false;
    const fail = (error) => {
      if (completed) return;
      completed = true;
      socket.destroy();
      callback(error);
    };
    socket.once('connect', () => {
      const target = (options.host || options.hostname) + ':' + (options.port || 443);
      let auth = '';
      if (proxy.username || proxy.password) {
        const user = decodeURIComponent(proxy.username || '');
        const pass = decodeURIComponent(proxy.password || '');
        auth = 'Proxy-Authorization: Basic ' + Buffer.from(user + ':' + pass).toString('base64') + '\r\n';
      }
      socket.write('CONNECT ' + target + ' HTTP/1.1\r\nHost: ' + target + '\r\nProxy-Connection: Keep-Alive\r\n' + auth + '\r\n');
    });
    const onData = (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      const end = buffer.indexOf('\r\n\r\n');
      if (end < 0) return;
      socket.pause();
      socket.removeListener('data', onData);
      const status = buffer.subarray(0, end).toString('latin1').split('\r\n')[0];
      if (!/^HTTP\/1\.[01] 200\b/.test(status)) {
        fail(new Error('Kilo Gateway proxy CONNECT failed: ' + status));
        return;
      }
      const rest = buffer.subarray(end + 4);
      if (rest.length) socket.unshift(rest);
      const secure = __kiloTls.connect({
        socket,
        servername: options.servername || options.host || options.hostname,
        ALPNProtocols: ['http/1.1'],
      });
      secure.once('secureConnect', () => {
        if (completed) return;
        completed = true;
        callback(null, secure);
      });
      secure.once('error', fail);
    };
    socket.on('data', onData);
    socket.once('error', fail);
    return undefined;
  }
}
function __kiloGatewayProxyAgent() {
  const value = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy;
  if (!value) return null;
  let url;
  try { url = new URL(value); } catch { return null; }
  if (url.protocol !== 'http:') return null;
  const key = url.href;
  if (!__kiloProxyAgents.has(key)) __kiloProxyAgents.set(key, new __KiloGatewayTunnelAgent(url));
  return __kiloProxyAgents.get(key);
}
globalThis.fetch = async function kiloCompatibleFetch(input, init) {
  let request;
  try { request = input instanceof Request && !init ? input : new Request(input, init); }
  catch { return __kiloOriginalFetch(input, init); }
  const url = new URL(request.url);
  if (url.hostname !== 'ai-gateway.kilo.ai') return __kiloOriginalFetch(input, init);
  const agent = __kiloGatewayProxyAgent();
  if (!agent) return __kiloOriginalFetch(input, init);
  const method = (init && init.method) || request.method || 'GET';
  const headers = Object.fromEntries(request.headers.entries());
  let body = null;
  if (method !== 'GET' && method !== 'HEAD') {
    if (init && Object.prototype.hasOwnProperty.call(init, 'body')) {
      const value = init.body;
      if (value == null) body = null;
      else if (typeof value === 'string' || Buffer.isBuffer(value)) body = value;
      else if (value instanceof ArrayBuffer) body = Buffer.from(value);
      else if (ArrayBuffer.isView(value)) body = Buffer.from(value.buffer, value.byteOffset, value.byteLength);
      else if (typeof value.getReader === 'function') body = Buffer.from(await new Response(value).arrayBuffer());
      else body = Buffer.from(String(value));
    } else {
      body = Buffer.from(await request.arrayBuffer());
    }
  }
  return new Promise((resolve, reject) => {
    const req = __kiloHttps.request(url, { method, headers, agent }, (res) => {
      const responseHeaders = new Headers();
      for (const [name, value] of Object.entries(res.headers)) {
        if (value === undefined) continue;
        if (Array.isArray(value)) for (const item of value) responseHeaders.append(name, item);
        else responseHeaders.set(name, String(value));
      }
      resolve(new Response(__kiloReadable.toWeb(res), {
        status: res.statusCode || 200,
        statusText: res.statusMessage || '',
        headers: responseHeaders,
      }));
    });
    req.once('error', reject);
    if (request.signal) {
      if (request.signal.aborted) { req.destroy(new Error('The operation was aborted')); return; }
      request.signal.addEventListener('abort', () => req.destroy(new Error('The operation was aborted')), { once: true });
    }
    if (body !== null) req.write(body);
    req.end();
  });
};

// Node 22 IA-32 compatibility: provide the Bun-style Worker API used by Kilo.
if (typeof globalThis.Worker !== 'function') {
  const { Worker: __KiloNodeWorker } = require('node:worker_threads');
  const __kiloPath = require('node:path');
  const __kiloUrl = require('node:url');
  const __kiloWorkerBootstrap = __kiloPath.join(__dirname, 'worker-bootstrap.mjs');
  class KiloNodeWorker {
    constructor(file, options = {}) {
      let entry;
      if (file instanceof URL) entry = __kiloUrl.fileURLToPath(file);
      else if (typeof file === 'string' && file.startsWith('file:')) entry = __kiloUrl.fileURLToPath(new URL(file));
      else entry = __kiloPath.resolve(__dirname, String(file));
      const worker = new __KiloNodeWorker(__kiloWorkerBootstrap, {
        workerData: { entry },
        env: options.env || process.env,
        execArgv: ['--require', __kiloPath.join(__dirname, 'node-bun-compat.cjs')],
      });
      this._worker = worker;
      this.onmessage = null;
      this.onerror = null;
      this._listeners = new Map();
      worker.on('message', (data) => {
        const event = { data };
        this.onmessage?.(event);
        for (const fn of this._listeners.get('message') || []) fn(event);
      });
      worker.on('error', (error) => {
        const event = { error, message: error.message };
        this.onerror?.(event);
        for (const fn of this._listeners.get('error') || []) fn(event);
      });
      worker.on('exit', (code) => {
        for (const fn of this._listeners.get('close') || []) fn({ code });
      });
      if (options.ref === false) worker.unref();
    }
    postMessage(value, transferList) { return this._worker.postMessage(value, transferList); }
    terminate() { return this._worker.terminate(); }
    addEventListener(type, fn) {
      if (!this._listeners.has(type)) this._listeners.set(type, new Set());
      this._listeners.get(type).add(fn);
    }
    removeEventListener(type, fn) { this._listeners.get(type)?.delete(fn); }
    ref() { this._worker.ref(); }
    unref() { this._worker.unref(); }
  }
  globalThis.Worker = KiloNodeWorker;
}
