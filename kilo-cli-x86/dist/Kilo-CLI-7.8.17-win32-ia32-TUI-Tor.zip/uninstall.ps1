$ErrorActionPreference = 'Stop'
$base = $env:LOCALAPPDATA
if (-not $base) { $base = Join-Path $HOME 'AppData\Local' }
$dest = Join-Path $base 'Programs\KiloCLI'
$destFull = [IO.Path]::GetFullPath($dest).TrimEnd('\')
$old = [Environment]::GetEnvironmentVariable('Path', 'User')
if ($old) {
    $parts = @($old -split ';' | Where-Object {
        $entry = $_.Trim()
        if (-not $entry) { return $false }
        try { return ([IO.Path]::GetFullPath($entry.Trim('"')).TrimEnd('\') -ine $destFull) }
        catch { return $true }
    })
    [Environment]::SetEnvironmentVariable('Path', ($parts -join ';'), 'User')
}
try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class KiloEnvironmentBroadcastRemove {
    [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);
}
'@
    [UIntPtr]$result = [UIntPtr]::Zero
    [KiloEnvironmentBroadcastRemove]::SendMessageTimeout([IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment', 2, 5000, [ref]$result) | Out-Null
} catch {
    Write-Warning 'PATH обновлён в реестре; может потребоваться повторный вход в Windows.'
}
if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
Write-Host 'Kilo CLI удалён. Пользовательские сессии и настройки в профиле не затронуты.' -ForegroundColor Green
