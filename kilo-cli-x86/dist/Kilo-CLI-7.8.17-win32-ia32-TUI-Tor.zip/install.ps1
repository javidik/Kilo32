$ErrorActionPreference = 'Stop'
$src = [IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$base = $env:LOCALAPPDATA
if (-not $base) { $base = Join-Path $HOME 'AppData\Local' }
$dest = Join-Path $base 'Programs\KiloCLI'

foreach ($name in @('node.exe', 'kilo-main.mjs', 'node-bun-compat.cjs', 'kilo.cmd')) {
    if (-not (Test-Path -LiteralPath (Join-Path $src $name) -PathType Leaf)) {
        throw "Required file not found: $name. Unpack the entire archive and retry."
    }
}

function Copy-Tree([string]$from, [string]$to) {
    [IO.Directory]::CreateDirectory($to) | Out-Null
    foreach ($file in [IO.Directory]::GetFiles($from)) {
        $name = [IO.Path]::GetFileName($file)
        if ($from -ieq $src -and $name -in @('install.ps1', 'install.bat')) { continue }
        [IO.File]::Copy($file, (Join-Path $to $name), $true)
    }
    foreach ($dir in [IO.Directory]::GetDirectories($from)) {
        $name = [IO.Path]::GetFileName($dir)
        Copy-Tree $dir (Join-Path $to $name)
    }
}
Copy-Tree $src $dest

$old = [Environment]::GetEnvironmentVariable('Path', 'User')
$parts = @()
if ($old) { $parts = @($old -split ';' | Where-Object { $_.Trim() }) }
$destFull = [IO.Path]::GetFullPath($dest).TrimEnd('\')
$present = $false
foreach ($part in $parts) {
    try {
        $entry = [IO.Path]::GetFullPath($part.Trim().Trim('"')).TrimEnd('\')
        if ($entry -ieq $destFull) { $present = $true; break }
    } catch { continue }
}
if (-not $present) {
    $newPath = if ($old) { $old.TrimEnd(';') + ';' + $dest } else { $dest }
    [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
}

try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class KiloEnvironmentBroadcast {
    [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);
}
'@
    [UIntPtr]$result = [UIntPtr]::Zero
    [KiloEnvironmentBroadcast]::SendMessageTimeout([IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment', 2, 5000, [ref]$result) | Out-Null
} catch {
    Write-Warning "Failed to broadcast PATH update. Sign out and back in to Windows if the new terminal does not see the kilo command."
}

Write-Host ''
Write-Host 'Kilo CLI installed.' -ForegroundColor Green
Write-Host "Folder: $dest"
Write-Host 'Open a NEW PowerShell or CMD window and run:  kilo'
Write-Host ''
& (Join-Path $dest 'kilo.cmd') --version
if ($LASTEXITCODE -ne 0) { throw 'Kilo startup check failed.' }
