@echo off
setlocal
set "NODE_USE_ENV_PROXY=1"
"%~dp0node.exe" "%~dp0proxy\launcher.cjs" %*
exit /b %errorlevel%
